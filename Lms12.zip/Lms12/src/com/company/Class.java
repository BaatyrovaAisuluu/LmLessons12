package com.company;

public class Class {
    double number;
    String words;
    int[] massif;

    public Class(double number, String words, int[] massif) {
        this.number = number;
        this.words = words;
        this.massif = massif;
    }
}